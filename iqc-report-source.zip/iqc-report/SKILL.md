---
name: iqc-report
description: Generate ISO 13485 compliant IQC statistical reports with 6SPC analysis including Cp/Cpk/Pp/Ppk indices, Xbar-R control charts, histograms, and normal probability plots. Use when - User requests IQC statistical analysis from inspection data files, Keywords like IQC, Cpk, 6SPC, process capability, control chart are mentioned, Quality inspection data needs to be converted to HTML reports with interactive charts. Supports Chinese quality inspection records with specifications like bilateral tolerance or symmetric diameter tolerance.
---

# IQC Statistical Report Generator

Generate ISO 13485 compliant IQC statistical analysis reports with 6SPC (Six Sigma Statistical Process Control) charts.

## Quick Start

```bash
# Parse inspection data and generate HTML report
python3 scripts/iqc_stats.py input.json output.html
```

## Workflow

1. **Parse input data** - Extract dimensions, measurements, and metadata from inspection file
2. **Calculate statistics** - Run 6SPC analysis (Cp/Cpk/Pp/Ppk, control limits)
3. **Generate HTML** - Embed data in template with Chart.js visualizations
4. **Validate output** - Check all values are within specification limits

## Input Format

JSON structure or parsed inspection record:

```json
{
  "meta": {
    "material_name": "推杆",
    "material_code": "1M131AISI1011000",
    "batch_no": "JSR25121502",
    "supplier": "思纳福医疗",
    "date": "2025.12.15"
  },
  "dimensions": [
    {
      "position": "位置1 Position 1",
      "spec": "27.80+0.10-0.00 mm",
      "measurements": [27.85, 27.84, ...]
    }
  ]
}
```

## Specification Parsing

See [spec_parsing.md](references/spec_parsing.md) for supported formats:
- Bilateral: `27.80+0.10-0.00`
- Symmetric: `Ø6.00±0.10`
- Unilateral: `73.20+0.00-0.15`

## Statistical Calculations

The script calculates:
- **Cp/Cpk** - Process capability indices
- **Pp/Ppk** - Overall performance indices
- **Xbar-R charts** - Control charts with UCL/LCL
- **6σ spread** - Six sigma process spread
- Subgroup statistics (n=5): mean, range, control limits

## Output

Interactive HTML report with:
- Meta information header
- Per-dimension analysis cards
- 5 Chart.js visualizations per dimension:
  - Capability plot (process 6σ vs spec tolerance)
  - Histogram
  - Xbar control chart
  - Range control chart
  - Normal probability plot
- Raw data table
- AI quality suggestions based on Cpk values

## Resources

- `scripts/iqc_stats.py` - Statistical calculation engine
- `assets/iqc_template.html` - HTML report template
- `references/spec_parsing.md` - Specification format reference
